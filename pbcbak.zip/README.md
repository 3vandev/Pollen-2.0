# Premier Boxing Association Discord Bot
Free and open source Discord bot which you are allowed to fork and run on your own server

### Getting started

Clone the repository
```sh
git clone https://github.com/3vandev/Pollen-2.0.git
```

Edit config.py and assign the TOKEN variable to your discord bots token [Discord Developer Portal](https://discord.com/login?redirect_to=%2Fdevelopers%2Fapplications)

Run the bot (make sure you are in the correct directory)
```sh
python main.py
```
